﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;

namespace DataContractService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public Employee GetEmployee(int id)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(localDb)\MSSQLLocalDb;Initial Catalog=DDU;Integrated Security=True");
            string s = "Select * from Employee where Id=" + id;
            con.Open();
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Employee e = new Employee();
                e.Id = Convert.ToInt32(dr["Id"]);
                e.DateOfBirth = Convert.ToDateTime(dr["DateOfBirth"]);
                e.Name = dr["Name"].ToString();
                e.Gender = dr["Gender"].ToString();
                return e; 
            }
            return null;
        }
    }
}
