﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1Lab3
{
    public partial class Form1 : Form
    {
        int selection = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (selection == 0)
            {
                ServiceReference1.Service1Client client = new ServiceReference1.Service1Client ("BasicHttpBinding_IService1");
                textBox1.Text = client.GetData(12);
            }else
            {
                ServiceReference1.Service1Client client = new ServiceReference1.Service1Client("NetTcpBinding_IService1");
               textBox1.Text = client.GetData(15);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            selection = 0;
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            selection = 1;
            
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (selection == 0)
            {
                ServiceReference1.Service1Client client = new ServiceReference1.Service1Client("BasicHttpBinding_IService1");
                textBox2.Text = client.MultiplyNumbers(12, 3);
            }
            else
            {
                ServiceReference1.Service1Client client = new ServiceReference1.Service1Client("NetTcpBinding_IService1");
                textBox2.Text = client.MultiplyNumbers(15, 3);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
