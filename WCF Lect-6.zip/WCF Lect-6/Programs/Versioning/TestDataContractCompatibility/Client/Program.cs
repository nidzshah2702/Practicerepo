﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.Service1Client client =
                new ServiceReference1.Service1Client();
            var data = client.UpdateEmployeeData(new ServiceReference1.EmpInfo { EmpId = 1,
                EmpName = "Avi",
                EmpCity = "Nadiad"
            });
            Console.WriteLine("Employee Id: {0}", data.EmpId);
            Console.WriteLine("Employee Name: {0}", data.EmpName);
            Console.WriteLine("Employee City: {0}", data.EmpCity);
            Console.ReadLine();
        }
    }
}
