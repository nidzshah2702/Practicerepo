﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace TestDataContractCompatibility
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        EmpInfo UpdateEmployeeData(EmpInfo info);
    }

    [DataContract]
    public class EmpInfo: IExtensibleDataObject
    {
        [DataMember]
        public int EmpId;
        [DataMember]
        public string EmpName;
        //[DataMember(IsRequired = false)]
        //public string EmpCity;
        public ExtensionDataObject ExtensionData { get; set; }
    }
}


