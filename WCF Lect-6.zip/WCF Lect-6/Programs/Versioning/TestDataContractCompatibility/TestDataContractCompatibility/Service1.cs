﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace TestDataContractCompatibility
{
    //[ServiceBehavior(IgnoreExtensionDataObject = true)]
    public class Service1 : IService1
    {
        private EmpInfo _Emp;
        public EmpInfo UpdateEmployeeData(EmpInfo info)
        {
            _Emp = info;
            return new EmpInfo { EmpId = info.EmpId,
                EmpName = info.EmpName,
                ExtensionData = info.ExtensionData
                //EmpCity = info.EmpCity
            };
        }
    }
}
